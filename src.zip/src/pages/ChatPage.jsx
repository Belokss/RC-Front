import React from 'react';

const ChatPage = () => {
  return (
    <div>
      <h1>Чат</h1>
      <p>Здесь будет интерфейс для вопросов по базе данных запчастей.</p>
    </div>
  );
};

export default ChatPage;